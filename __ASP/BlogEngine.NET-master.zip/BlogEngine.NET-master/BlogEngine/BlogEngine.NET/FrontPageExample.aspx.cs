﻿using BlogEngine.Core.Web.Controls;
using System;

namespace BlogEngine.NET
{
    public partial class FrontPage : BlogBasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}